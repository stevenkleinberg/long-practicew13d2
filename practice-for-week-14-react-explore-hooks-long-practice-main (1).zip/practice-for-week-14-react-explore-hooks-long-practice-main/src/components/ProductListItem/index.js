import ProductListItem from "./ProductListItem";

export default ProductListItem;