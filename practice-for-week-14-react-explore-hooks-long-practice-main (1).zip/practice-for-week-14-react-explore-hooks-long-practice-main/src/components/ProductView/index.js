import ProductView from "./ProductView";

export default ProductView;